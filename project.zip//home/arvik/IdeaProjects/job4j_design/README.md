# job4j_design
[![Build Status](https://travis-ci.com/ArvikVan/job4j_design.svg?branch=master)](https://travis-ci.com/ArvikVan/job4j_design)
[![codecov](https://codecov.io/gh/ArvikVan/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/ArvikVan/job4j_design)


